from django.apps import AppConfig


class PollingwebsiteConfig(AppConfig):
    default_auto_field ='django.db.models.BigAutofield'
    name = 'pollingwebsite'
